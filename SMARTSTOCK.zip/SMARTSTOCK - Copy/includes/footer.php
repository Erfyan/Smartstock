<?php
// includes/footer.php
?>

<style>
.footer {
    padding: 20px;
    text-align: center;
    color: #6c757d;
    font-size: 14px;
}
</style>

<div class="footer">
    © <?= date('Y'); ?> SmartStock Sistem • All rights reserved
</div>

<!-- Bootstrap JS (WAJIB untuk modal) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</body>
</html>